package com.mobcafeui.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Non-Minecraft logic; pure and deterministic for unit tests. */
public final class OrderLogic {
    public static final int CUSTOM_ORDER_START = 100;
    private OrderLogic() { }

    /** Draw uniformly from actual enabled slots, not from item ids or a fixed vanilla list. */
    public static int chooseSlot(List<Boolean> enabledAndPresent, Random rng) {
        List<Integer> eligible = new ArrayList<>();
        for (int i=0;i<enabledAndPresent.size();i++) if (Boolean.TRUE.equals(enabledAndPresent.get(i))) eligible.add(i);
        return eligible.isEmpty() ? -1 : eligible.get(rng.nextInt(eligible.size()));
    }
    public static int marker(int slot) { return CUSTOM_ORDER_START + CatalogLogic.select(slot); }
    public static boolean isCustom(int marker) {
        return marker >= CUSTOM_ORDER_START && marker < CUSTOM_ORDER_START + CatalogLogic.SLOTS;
    }
    public static int slotFromMarker(int marker) {
        if (!isCustom(marker)) throw new IllegalArgumentException("not a custom order");
        return marker - CUSTOM_ORDER_START;
    }
    public static int payout(int price, boolean quick) {
        return CatalogLogic.price(price) + (quick ? 1 : 0);
    }
}
