package com.mobcafeui.core;

/** Pure Java rules, independently testable without launching Minecraft. */
public final class CatalogLogic {
    public static final int SLOTS = 27;
    public static final int MIN_PRICE = 1;
    public static final int MAX_PRICE = 64;
    private CatalogLogic() { }

    public static int price(int proposed) {
        return Math.max(MIN_PRICE, Math.min(MAX_PRICE, proposed));
    }

    public static int select(int slot) {
        if (slot < 0 || slot >= SLOTS) throw new IllegalArgumentException("slot out of range");
        return slot;
    }

    public static int buttonId(int slot, int action) {
        select(slot);
        if (action < 0 || action > 2) throw new IllegalArgumentException("unknown action");
        return slot * 3 + action;
    }

    public static int slotForButton(int buttonId) { return select(buttonId / 3); }
    public static int actionForButton(int buttonId) { return buttonId % 3; }
}
