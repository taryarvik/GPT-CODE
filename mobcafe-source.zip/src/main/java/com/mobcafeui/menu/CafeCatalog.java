package com.mobcafeui.menu;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mobcafeui.core.CatalogLogic;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** Each Cafe Board's persistent, independent 27-slot restaurant catalogue. */
public final class CafeCatalog {
    public static final Codec<CafeCatalog> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.INT.fieldOf("board_id").forGetter(c -> c.boardId),
        FoodEntry.CODEC.listOf().fieldOf("products").forGetter(c -> c.entries)
    ).apply(instance, CafeCatalog::new));

    private final int boardId;
    private final List<FoodEntry> entries;

    public CafeCatalog(int boardId, List<FoodEntry> saved) {
        this.boardId = boardId;
        this.entries = new ArrayList<>(CatalogLogic.SLOTS);
        for (int i = 0; i < CatalogLogic.SLOTS; i++) {
            FoodEntry entry = i < saved.size() ? saved.get(i) : FoodEntry.empty();
            this.entries.add(entry);
        }
    }

    public CafeCatalog(int boardId) { this(boardId, List.of()); }
    public int boardId() { return boardId; }
    public List<FoodEntry> entries() { return List.copyOf(entries); }
    public FoodEntry get(int slot) { return entries.get(CatalogLogic.select(slot)); }
    public void set(int slot, FoodEntry entry) { entries.set(CatalogLogic.select(slot), entry); }
    public void setExample(int slot, ItemStack stack) {
        FoodEntry prev = get(slot);
        set(slot, new FoodEntry(stack, prev.price(), !stack.isEmpty()));
    }
    public void adjustPrice(int slot, int delta) {
        FoodEntry p = get(slot);
        set(slot, new FoodEntry(p.item(), CatalogLogic.price(p.price() + delta), p.enabled()));
    }
    public void toggle(int slot) {
        FoodEntry p = get(slot);
        if (!p.item().isEmpty()) set(slot, new FoodEntry(p.item(), p.price(), !p.enabled()));
    }
}
