package com.mobcafeui.menu;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.item.ItemStack;

/** A saved product example; retains modded registry ID and all stack components. */
public record FoodEntry(ItemStack item, int price, boolean enabled) {
    public static final Codec<FoodEntry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        ItemStack.OPTIONAL_CODEC.orElse(ItemStack.EMPTY).fieldOf("sample").forGetter(FoodEntry::item),
        Codec.INT.fieldOf("price").forGetter(FoodEntry::price),
        Codec.BOOL.fieldOf("enabled").forGetter(FoodEntry::enabled)
    ).apply(instance, FoodEntry::new));

    public FoodEntry {
        item = item.copyWithCount(item.isEmpty() ? 0 : 1);
        price = com.mobcafeui.core.CatalogLogic.price(price);
    }

    public static FoodEntry empty() { return new FoodEntry(ItemStack.EMPTY, 2, false); }
}
