package com.mobcafeui.menu;

import com.mojang.serialization.Codec;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** One saved registry per dimension. Minecraft serializes ItemStack codecs with world registry context. */
public final class CatalogStore extends SavedData {
    public static final Codec<CatalogStore> CODEC = CafeCatalog.CODEC.listOf().xmap(CatalogStore::new, x -> List.copyOf(x.catalogs.values()));
    public static final SavedDataType<CatalogStore> TYPE = new SavedDataType<>(
        Identifier.fromNamespaceAndPath("mobcafeui", "restaurant_catalogs"), CatalogStore::new, CODEC);
    private final Map<Integer, CafeCatalog> catalogs = new LinkedHashMap<>();

    public CatalogStore() { }
    private CatalogStore(List<CafeCatalog> saved) {
        for (CafeCatalog cat : saved) if (cat.boardId() > 0) catalogs.put(cat.boardId(), cat);
    }

    public static CatalogStore get(ServerLevel level) { return level.getDataStorage().computeIfAbsent(TYPE); }
    public CafeCatalog cafe(int id) {
        if (id < 1) throw new IllegalArgumentException("invalid cafe id");
        return catalogs.computeIfAbsent(id, this::newCatalog);
    }
    private CafeCatalog newCatalog(int id) { setDirty(); return new CafeCatalog(id); }
    public void changed() { setDirty(); }
    public Collection<CafeCatalog> all() { return List.copyOf(catalogs.values()); }
}
