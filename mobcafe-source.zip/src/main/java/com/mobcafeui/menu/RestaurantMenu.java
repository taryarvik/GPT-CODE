package com.mobcafeui.menu;

import com.mobcafeui.CafeUi;
import com.mobcafeui.core.CatalogLogic;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.core.component.DataComponents;

/**
 * The first 27 slots are ghost recipes, not storage. Nothing is consumed.
 * Every mutation runs server-side and is saved immediately. Price + enabled sync via data slots.
 */
public final class RestaurantMenu extends AbstractContainerMenu {
    public static final int SLOTS = CatalogLogic.SLOTS;
    private final Inventory playerInventory;
    private final int boardId;
    private final SimpleContainer ghost = new SimpleContainer(SLOTS);
    private final ContainerData data = new SimpleContainerData(SLOTS * 2);
    private final CafeCatalog catalog; // null on client
    private final CatalogStore store;  // null on client

    /** NeoForge client constructor: its extra bytes come from CatalogOpener. */
    public RestaurantMenu(int windowId, Inventory inventory, RegistryFriendlyByteBuf buffer) {
        this(windowId, inventory, buffer.readVarInt(), null, null);
    }

    public static RestaurantMenu server(int windowId, Inventory inv, int boardId) {
        if (!(inv.player instanceof net.minecraft.server.level.ServerPlayer player))
            throw new IllegalArgumentException("server inventory required");
        var store = CatalogStore.get(player.serverLevel());
        return new RestaurantMenu(windowId, inv, boardId, store, store.cafe(boardId));
    }

    private RestaurantMenu(int windowId, Inventory inventory, int boardId, CatalogStore store, CafeCatalog catalog) {
        super(CafeUi.RESTAURANT.get(), windowId);
        this.playerInventory = inventory;
        this.boardId = boardId;
        this.store = store;
        this.catalog = catalog;
        for (int i = 0; i < SLOTS; i++) {
            if (catalog != null) {
                FoodEntry p = catalog.get(i);
                ghost.setItem(i, p.item().copy());
                data.set(i, p.price());
                data.set(SLOTS+i, p.enabled() ? 1 : 0);
            }
            final int slot = i;
            addSlot(new Slot(ghost, i, 48+(i%9)*18, 36+(i/9)*21) {
                @Override public boolean mayPlace(ItemStack stack) { return false; }
                @Override public boolean mayPickup(Player player) { return false; }
            });
        }
        // Player's original inventory. Works for arbitrary modded item types.
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++)
            addSlot(new Slot(inventory, col+row*9+9, 48+col*18, 153+row*18));
        for (int col = 0; col < 9; col++)
            addSlot(new Slot(inventory, col, 48+col*18, 211));
        addDataSlots(data);
    }

    public int boardId() { return boardId; }
    public ItemStack example(int slot) { return ghost.getItem(slot); }
    public int price(int slot) { return data.get(CatalogLogic.select(slot)); }
    public boolean enabled(int slot) { return data.get(CatalogLogic.select(slot)+SLOTS) == 1; }

    private void update(int slot, ItemStack stack) {
        if (catalog == null || store == null) return;
        // It is an example, not an inventory deposit. Only one item is stored.
        // Food/modded food normally has a consumable component. Empty hand removes a slot.
        if (!stack.isEmpty() && !isFood(stack)) return;
        catalog.setExample(slot, stack.isEmpty() ? ItemStack.EMPTY : stack.copyWithCount(1));
        ghost.setItem(slot, catalog.get(slot).item().copy());
        data.set(slot+SLOTS, catalog.get(slot).enabled() ? 1 : 0);
        store.changed();
        broadcastChanges();
    }

    private static boolean isFood(ItemStack stack) {
        // Any consumable, including modded food and drink; relies on data components,
        // not a hard-coded list of item IDs.
        return stack.has(DataComponents.CONSUMABLE) || stack.has(DataComponents.FOOD);
    }

    @Override
    public void clicked(int slotIndex, int buttonNum, ContainerInput input, Player player) {
        if (slotIndex >= 0 && slotIndex < SLOTS) {
            if (catalog == null) return; // no speculative client mutation
            if (input == ContainerInput.PICKUP) {
                ItemStack carried = getCarried();
                if (carried.isEmpty() && buttonNum == 1) update(slotIndex, ItemStack.EMPTY);
                else if (!carried.isEmpty()) update(slotIndex, carried);
            } else if (input == ContainerInput.SWAP && buttonNum >= 0 && buttonNum < 9) {
                update(slotIndex, player.getInventory().getItem(buttonNum));
            } else if (input == ContainerInput.THROW) {
                update(slotIndex, ItemStack.EMPTY);
            }
            return;
        }
        super.clicked(slotIndex, buttonNum, input, player);
    }

    @Override
    public boolean canDragTo(Slot slot) { return slot.container != ghost && super.canDragTo(slot); }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (catalog != null && slotIndex >= SLOTS && slotIndex < slots.size()) {
            ItemStack stack = slots.get(slotIndex).getItem();
            if (isFood(stack)) for (int i = 0; i < SLOTS; i++) if (ghost.getItem(i).isEmpty()) {
                update(i, stack);
                break;
            }
        }
        // Never remove the original item or produce a duplicate stack.
        return ItemStack.EMPTY;
    }

    /** button ids: for each slot: 0 = -1 gem; 1 = +1 gem; 2 = toggle availability */
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (catalog == null || store == null || buttonId < 0 || buttonId >= SLOTS*3) return false;
        int slot = CatalogLogic.slotForButton(buttonId);
        int operation = CatalogLogic.actionForButton(buttonId);
        if (operation == 2) catalog.toggle(slot);
        else catalog.adjustPrice(slot, operation == 0 ? -1 : 1);
        FoodEntry newValue = catalog.get(slot);
        data.set(slot, newValue.price());
        data.set(slot + SLOTS, newValue.enabled() ? 1 : 0);
        store.changed();
        broadcastChanges();
        return true;
    }

    @Override public boolean stillValid(Player player) {
        // Menu only associated with the currently selected board. Protect against stale windows.
        var objective = player.getScoreboard().getObjective("cafe_active");
        if (objective == null) return false;
        var current = player.getScoreboard().getPlayerScoreInfo(player, objective);
        return current != null && current.value() == boardId;
    }
}
