package com.mobcafeui.menu;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ReadOnlyScoreInfo;

/** Hook to the existing Lite Cafe Board selection; does not edit its state. */
public final class CatalogOpener {
    private CatalogOpener() { }

    public static int open(ServerPlayer player) {
        Objective selected = player.getScoreboard().getObjective("cafe_active");
        ReadOnlyScoreInfo current = selected == null ? null : player.getScoreboard().getPlayerScoreInfo(player, selected);
        int boardId = current == null ? 0 : current.value();
        if (boardId < 1) {
            player.displayClientMessage(Component.literal("§eСперва открой своё Café Board (мишень), затем редактор."), false);
            return 0;
        }
        int id = boardId;
        player.openMenu(new SimpleMenuProvider(
            (window, inv, p) -> RestaurantMenu.server(window, inv, id),
            Component.literal("Mob Café · Ресторанное меню")), buffer -> buffer.writeVarInt(id));
        return 1;
    }
}
