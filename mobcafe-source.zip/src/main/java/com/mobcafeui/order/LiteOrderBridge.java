package com.mobcafeui.order;

import com.mobcafeui.core.CatalogLogic;
import com.mobcafeui.core.OrderLogic;
import com.mobcafeui.menu.CafeCatalog;
import com.mobcafeui.menu.CatalogStore;
import com.mobcafeui.menu.FoodEntry;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Commands called from a *patched copy* of Mob Cafe Lite 0.9.10.
 * The datapack owns movement, seating and dialogue; Java owns arbitrary food
 * selection, one-item consumption and payment. Commands run only server-side.
 */
public final class LiteOrderBridge {
    private static final Random RANDOM = new Random();
    private LiteOrderBridge() { }

    public static void register(CommandDispatcher<CommandSourceStack> commands) {
        commands.register(Commands.literal("cafeui")
            .executes(c -> com.mobcafeui.menu.CatalogOpener.open(c.getSource().getPlayerOrException()))
            .then(Commands.literal("assign").executes(c -> assign(c.getSource())))
            .then(Commands.literal("serve").executes(c -> serve(c.getSource())))
            .then(Commands.literal("barrel").executes(c -> barrel(c.getSource())))
            .then(Commands.literal("cancel").executes(c -> cancel(c.getSource()))));
    }

    private static int assign(CommandSourceStack source) {
        Entity guest = source.getEntity();
        if (guest == null || !guest.getTags().contains("cafe_guest") || !(guest.level() instanceof ServerLevel level)) return 0;
        if (ScoreAccessUtil.get(guest, "cafe_stage") != 8) return 0;
        int boardId = ScoreAccessUtil.get(guest, "cafe_board_id");
        if (boardId <= 0) return 0;
        OrderStore orders = OrderStore.get(level);
        if (orders.contains(guest.getStringUUID())) return 0; // no double-order
        CafeCatalog cafe = CatalogStore.get(level).cafe(boardId);
        List<Boolean> eligibility = new ArrayList<>();
        for (int i = 0; i < CatalogLogic.SLOTS; i++) {
            FoodEntry product = cafe.get(i);
            eligibility.add(!product.item().isEmpty() && product.enabled());
        }
        int slot = OrderLogic.chooseSlot(eligibility, RANDOM);
        if (slot < 0) return 0; // use original Lite's vanilla order when catalog is empty
        FoodEntry product = cafe.get(slot);
        ScoreAccessUtil.put(guest, "cafe_order", OrderLogic.marker(slot));
        ScoreAccessUtil.put(guest, "cafe_price", product.price());

        // An actual item model floating above the seated guest, including modded items.
        Display.ItemDisplay display = new Display.ItemDisplay(EntityType.ITEM_DISPLAY, level);
        display.setItemStack(product.item().copyWithCount(1));
        display.setItemTransform(ItemDisplayContext.FIXED);
        display.snapTo(guest.getX(), guest.getY() + 2.15, guest.getZ());
        display.addTag("cafe_ui_order_display");
        level.addFreshEntity(display);
        orders.put(new OrderStore.Pending(guest.getStringUUID(), boardId, product, display.getStringUUID()));
        return 1;
    }

    private static int serve(CommandSourceStack source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) return 0;
        ServerLevel level = player.serverLevel();
        List<? extends LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class,
            new AABB(player.blockPosition()).inflate(4.5),
            e -> e.getTags().contains("cafe_guest") && e.getTags().contains("cafe_selected")
               && ScoreAccessUtil.get(e, "cafe_stage") == 8 && OrderLogic.isCustom(ScoreAccessUtil.get(e, "cafe_order")));
        if (nearby.isEmpty()) return 0;
        LivingEntity guest = nearby.getFirst();
        OrderStore.Pending order = OrderStore.get(level).get(guest.getStringUUID());
        if (order == null || order.boardId() != ScoreAccessUtil.get(guest, "cafe_board_id")) return 0;
        ItemStack hand = player.getMainHandItem();
        if (!matches(hand, order.offer().item())) {
            player.displayClientMessage(Component.literal("§cНеверное блюдо. Нужно: " + order.offer().item().getHoverName().getString()), true);
            return 0;
        }
        if (!player.getAbilities().instabuild) hand.shrink(1);
        finish(source, level, guest, order, guest.blockPosition());
        return 1;
    }

    private static int barrel(CommandSourceStack source) {
        if (!(source.getEntity() instanceof LivingEntity guest) || !(guest.level() instanceof ServerLevel level)) return 0;
        if (ScoreAccessUtil.get(guest, "cafe_stage") != 8) return 0;
        OrderStore.Pending order = OrderStore.get(level).get(guest.getStringUUID());
        if (order == null || order.boardId() != ScoreAccessUtil.get(guest, "cafe_board_id")) return 0;
        // Source executor = guest, but command *position* stays at the cafe_counter marker.
        BlockPos pos = BlockPos.containing(source.getPosition());
        BlockEntity block = level.getBlockEntity(pos);
        if (!(block instanceof Container inv)) return 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!matches(stack, order.offer().item())) continue;
            stack.shrink(1);
            inv.setChanged();
            finish(source, level, guest, order, pos);
            return 1;
        }
        return 0;
    }

    private static boolean matches(ItemStack actual, ItemStack expected) {
        return !actual.isEmpty() && !expected.isEmpty()
            && ItemStack.isSameItemSameComponents(actual, expected);
    }

    private static int cancel(CommandSourceStack source) {
        Entity guest = source.getEntity();
        if (guest == null || !(guest.level() instanceof ServerLevel level)) return 0;
        OrderStore.Pending p = OrderStore.get(level).remove(guest.getStringUUID());
        if (p == null) return 0;
        removeDisplay(level, p);
        return 1;
    }

    private static void finish(CommandSourceStack source, ServerLevel level, Entity guest,
                               OrderStore.Pending order, BlockPos payoutPoint) {
        // Remove before running any other function: prevents reentrant or double payment.
        OrderStore.Pending removed = OrderStore.get(level).remove(guest.getStringUUID());
        if (removed == null) return;
        removeDisplay(level, removed);
        int patience = ScoreAccessUtil.get(guest, "cafe_patience");
        int money = OrderLogic.payout(order.offer().price(), patience >= 1600);
        ItemEntity emeralds = new ItemEntity(level, payoutPoint.getX()+0.5,
            payoutPoint.getY()+1.0, payoutPoint.getZ()+0.5,
            new ItemStack(Items.EMERALD, money));
        emeralds.setPickUpDelay(10);
        level.addFreshEntity(emeralds);
        // Reuse Lite's meal timer, particles, reputation and farewell flow.
        source.getServer().getCommands().performPrefixedCommand(
            source.withEntity(guest).withPosition(guest.position()),
            "function mobcafe_lite:guest/complete");
    }

    private static void removeDisplay(ServerLevel level, OrderStore.Pending order) {
        if (order.displayUuid() == null || order.displayUuid().isBlank()) return;
        try {
            Entity display = level.getEntity(UUID.fromString(order.displayUuid()));
            if (display != null && display.getTags().contains("cafe_ui_order_display")) display.discard();
        } catch (IllegalArgumentException ignored) { }
    }
}
