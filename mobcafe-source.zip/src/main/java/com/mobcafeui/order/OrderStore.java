package com.mobcafeui.order;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mobcafeui.menu.FoodEntry;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Frozen product snapshots: editing a menu cannot change an already placed order. */
public final class OrderStore extends SavedData {
    public record Pending(String guestUuid, int boardId, FoodEntry offer, String displayUuid) {
        public static final Codec<Pending> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.fieldOf("guest").forGetter(Pending::guestUuid),
            Codec.INT.fieldOf("cafe").forGetter(Pending::boardId),
            FoodEntry.CODEC.fieldOf("offer").forGetter(Pending::offer),
            Codec.STRING.optionalFieldOf("display", "").forGetter(Pending::displayUuid)
        ).apply(i, Pending::new));
    }
    public static final Codec<OrderStore> CODEC = Pending.CODEC.listOf().xmap(OrderStore::new, s -> new ArrayList<>(s.orders.values()));
    public static final SavedDataType<OrderStore> TYPE = new SavedDataType<>(
        Identifier.fromNamespaceAndPath("mobcafeui", "guest_orders"), OrderStore::new, CODEC);
    private final Map<String, Pending> orders = new LinkedHashMap<>();
    public OrderStore() { }
    private OrderStore(List<Pending> saved) {
        for (Pending order : saved) if (order.boardId() > 0) orders.put(order.guestUuid(), order);
    }
    public static OrderStore get(ServerLevel level) { return level.getDataStorage().computeIfAbsent(TYPE); }
    public Pending get(String uuid) { return orders.get(uuid); }
    public boolean contains(String uuid) { return orders.containsKey(uuid); }
    public void put(Pending order) { orders.put(order.guestUuid(), order); setDirty(); }
    public Pending remove(String uuid) { Pending p = orders.remove(uuid); if (p != null) setDirty(); return p; }
}
