package com.mobcafeui.order;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import net.minecraft.world.scores.Scoreboard;

/** Backwards-compatible bridge to Mob Café Lite's existing scoreboard. */
public final class ScoreAccessUtil {
    private ScoreAccessUtil() { }
    public static int get(Entity entity, String name) {
        Scoreboard board = entity.level().getScoreboard();
        Objective objective = board.getObjective(name);
        if (objective == null) return 0;
        ReadOnlyScoreInfo info = board.getPlayerScoreInfo(entity, objective);
        return info == null ? 0 : info.value();
    }
    public static boolean put(Entity entity, String name, int value) {
        Scoreboard board = entity.level().getScoreboard();
        Objective objective = board.getObjective(name);
        if (objective == null) return false;
        board.getOrCreatePlayerScore(entity, objective).set(value);
        return true;
    }
}
