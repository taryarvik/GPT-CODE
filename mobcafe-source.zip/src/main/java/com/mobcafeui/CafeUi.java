package com.mobcafeui;

import com.mobcafeui.menu.RestaurantMenu;
import com.mobcafeui.order.LiteOrderBridge;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

/**
 * Distinct addon mod id so the legacy Lite datapack remains untouched.
 * /cafeui opens a real screen, bound to the legacy cafe_active scoreboard.
 */
@Mod(CafeUi.MODID)
public final class CafeUi {
    public static final String MODID = "mobcafeui";
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(BuiltInRegistries.MENU, MODID);
    public static final DeferredHolder<MenuType<?>, MenuType<RestaurantMenu>> RESTAURANT =
            MENUS.register("restaurant", () -> IMenuTypeExtension.create(RestaurantMenu::new));

    public CafeUi(IEventBus modBus, Dist dist) {
        MENUS.register(modBus);
        NeoForge.EVENT_BUS.addListener(CafeUi::commands);
        if (dist == Dist.CLIENT) {
            com.mobcafeui.client.ClientSetup.register(modBus);
        }
    }

    private static void commands(RegisterCommandsEvent event) {
        LiteOrderBridge.register(event.getDispatcher());
    }
}
