package com.mobcafeui.client;

import com.mobcafeui.core.CatalogLogic;
import com.mobcafeui.menu.RestaurantMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Custom oak / parchment interface. Renders inside Minecraft, not as a separate webpage. */
public final class RestaurantScreen extends AbstractContainerScreen<RestaurantMenu> {
    private static final int WOOD = 0xFF3C281C;
    private static final int DARK = 0xFF21170F;
    private static final int EDGE = 0xFFB08A50;
    private static final int PARCHMENT = 0xFFE2C99A;
    private static final int GOLD = 0xFFF1C66B;
    private int selected = 0;

    public RestaurantScreen(RestaurantMenu menu, Inventory inv, Component title) {
        super(menu, inv, title, 270, 238);
        inventoryLabelY = 141;
        titleLabelX = 15;
        titleLabelY = 8;
    }

    @Override protected void init() {
        super.init();
        int x = leftPos + 219;
        int y = topPos + 41;
        addRenderableWidget(Button.builder(Component.literal("−"), b -> press(0))
                .bounds(x, y, 19, 19).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> press(1))
                .bounds(x+22, y, 19, 19).build());
        addRenderableWidget(Button.builder(Component.literal("ВКЛ"), b -> press(2))
                .bounds(x, y+28, 41, 20).build());
    }

    private void press(int action) {
        if (minecraft != null && minecraft.gameMode != null)
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId,
                    CatalogLogic.buttonId(selected, action));
    }

    @Override protected void slotClicked(Slot slot, int slotId, int mouseButton,
                                          net.minecraft.world.inventory.ContainerInput input) {
        if (slotId >= 0 && slotId < CatalogLogic.SLOTS) selected = slotId;
        super.slotClicked(slot, slotId, mouseButton, input);
    }

    @Override public void extractContents(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        drawWoodenBackground(g);
        super.extractContents(g, mouseX, mouseY, delta);
    }

    private void drawWoodenBackground(GuiGraphicsExtractor g) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x + imageWidth, y + imageHeight, DARK);
        g.fill(x+3, y+3, x+imageWidth-3, y+imageHeight-3, EDGE);
        g.fill(x+5, y+5, x+imageWidth-5, y+imageHeight-5, WOOD);
        // Procedural wood grain; no resource pack overrides of vanilla buttons.
        for(int n=0;n<17;n++) {
            int yy = y+10+n*13;
            g.fill(x+8,yy,x+imageWidth-8,yy+1,0xFF493121);
        }
        g.fill(x+11,y+11,x+imageWidth-11,y+30,PARCHMENT);
        g.fill(x+41,y+32,x+214,y+107,0xFF281D15);
        for(int i=0;i<CatalogLogic.SLOTS;i++) {
            int sx=x+47+(i%9)*18, sy=y+35+(i/9)*21;
            g.fill(sx-2,sy-2,sx+17,sy+17, i==selected ? GOLD : 0xFF80603F);
            g.fill(sx,sy,sx+16,sy+16,0xFF493726);
            if (menu.enabled(i) && !menu.example(i).isEmpty())
                g.fill(sx+13,sy+13,sx+16,sy+16,0xFF74CE75);
        }
        g.fill(x+215,y+33,x+265,y+121,0xFF2A1D12);
        g.fill(x+41,y+144,x+215,y+232,0xFF291D16);
        // Inventory slot framing.
        for(int i=0;i<36;i++) {
            int sx=x+47+(i%9)*18, sy=y+152+(i/9)*18+(i>=27?4:0);
            g.fill(sx-1,sy-1,sx+17,sy+17,0xFF745537);
            g.fill(sx,sy,sx+16,sy+16,0xFF433124);
        }
    }

    @Override protected void extractLabels(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        g.text(font, "☕  MOB CAFÉ  ·  МЕНЮ РЕСТОРАНА", 16, 17, 0xFF47301C, false);
        g.text(font, "Блюда (образцы)", 43, 118, GOLD, false);
        g.text(font, "Инвентарь", 47, 136, 0xFFF4D9AA, false);
        g.text(font, "№"+(selected+1), 224, 38, 0xFFE8CE94, false);
        g.text(font, "" + menu.price(selected) + " ◆", 221, 101, 0xFFF2D277, false);
        g.text(font, menu.enabled(selected) ? "Продаётся" : "Выключено", 215, 117,
                menu.enabled(selected) ? 0xFF8CDB91 : 0xFFC8A19A, false);
    }

}
