package com.mobcafeui.client;

import com.mobcafeui.CafeUi;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Only loaded on the physical client. */
public final class ClientSetup {
    private ClientSetup() { }
    public static void register(IEventBus bus) { bus.addListener(ClientSetup::onScreens); }
    private static void onScreens(RegisterMenuScreensEvent event) {
        event.register(CafeUi.RESTAURANT.get(), RestaurantScreen::new);
    }
}
