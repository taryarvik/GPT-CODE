#!/usr/bin/env python3
"""Patches a COPY of the known-working lowcodefml Mob Café Lite 0.9.10; original is never edited."""
from pathlib import Path
import sys, json, zipfile
root=Path(__file__).resolve().parents[1]
source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'bridge'/'original-lite-0.9.10.jar'
out=Path(sys.argv[2]) if len(sys.argv)>2 else root/'bridge'/'MobCafe-Lite-0.9.10-UI-Bridge.jar'
if not source.exists(): raise SystemExit('Need original Lite JAR: ' + str(source))
patched={}
with zipfile.ZipFile(source) as z:
    content={n:z.read(n) for n in z.namelist() if not n.endswith('/')}

def edit(file, fn):
    name='data/mobcafe_lite/function/'+file+'.mcfunction'
    if name not in content: raise ValueError('Missing function: '+name)
    original=content[name].decode('utf8')
    new=fn(original)
    if new==original: raise ValueError('Failed patch: '+name)
    content[name]=new.encode('utf8')
    patched[name]=1

def seated(s):
    target='scoreboard players set @s cafe_stage_time 0'
    assert target in s
    return s.replace(target, target+'\n# Server-side mod chooses a frozen product from this cafe, if configured.\ncafeui assign',1)
edit('seating/seated_waiting',seated)

def hand(s):
    return '''# The Java addon delivers arbitrary items (including modded consumables).\ntag @s remove cafe_ui_handled\nexecute if entity @e[tag=cafe_selected,scores={cafe_order=100..126,cafe_stage=8},distance=..4] run tag @s add cafe_ui_handled\nexecute if entity @s[tag=cafe_ui_handled] run cafeui serve\nexecute if entity @s[tag=cafe_ui_handled] run return 0\n'''+s
edit('hand/try',hand)

def barrel(s):
    target='execute unless entity @e[tag=cafe_selected,distance=..96] run return 0'
    assert target in s
    new=target+'\n# Let Java inspect all barrel slots for modded food. Source position stays at counter marker.\nexecute as @e[tag=cafe_selected,scores={cafe_order=100..126,cafe_stage=8},distance=..96,limit=1] run cafeui barrel'
    return s.replace(target,new,1)
edit('counter/scan',barrel)

def order_name(s):
    return 'execute if score @s cafe_order matches 100..126 run data modify storage mobcafe_lite:seating view.order set value "Блюдо из меню ресторана"\n'+s
edit('seating/order_name',order_name)
for path in ['guest/finish_visit','guest/angry','guest/cleanup_only']:
    edit(path,lambda s:'execute if score @s cafe_order matches 100..126 run cafeui cancel\n'+s)

main='data/mobcafe_lite/dialog/main.json'
data=json.loads(content[main]); changed=False
for action in data['actions']:
    if action.get('label','').find('МЕНЮ И ЦЕНЫ')>=0:
        action['label']='🍞  МЕНЮ БЛЮД (JAVA)'
        action['action']={'type':'run_command','command':'cafeui'}
        changed=True
if not changed: raise ValueError('Could not find restaurant menu button')
content[main]=json.dumps(data,ensure_ascii=False,indent=2).encode('utf8')
metadata='META-INF/neoforge.mods.toml'
assert b'lowcodefml' in content[metadata]
text=content[metadata].decode('utf8')
text=text.replace('version="0.9.10-lower-seats"','version="0.9.10-ui-bridge"')
text=text.replace('displayName="Mob Caf\u00e9 Lite \u2014 Lower Seats 0.9.10"', 'displayName="Mob Caf\u00e9 Lite 0.9.10 \u2014 Java UI Bridge"')
# Java addon declares required dependency on Lite; no reciprocal dependency/cycle.
content[metadata]=text.encode('utf8')
out.parent.mkdir(exist_ok=True,parents=True)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,buffer in sorted(content.items()): z.writestr(name,buffer)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for n in patched: assert n in z.namelist()
print('Patched functions:',len(patched),'output:',out,'bytes',out.stat().st_size)
