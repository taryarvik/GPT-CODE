#!/usr/bin/env python3
"""OPTIONAL: add launch action to legacy Lite 0.9.10 dialog without changing its game logic.

Usage: python3 tools/patch_lite_menu.py path/to/MobCafe-Lite-0.9.10-Lower-Seats-26.3.jar
Requires a compiled mobcafeui addon in the same mods folder before using the new button.
"""
import json
import sys
import zipfile
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("usage: patch_lite_menu.py legacy_0.9.10.jar")
src = Path(sys.argv[1])
dest = src.with_name("MobCafe-Lite-0.9.10-With-GUI-Entry.jar")
assert src.exists(), "Original jar not found"
main_file = "data/mobcafe_lite/dialog/main.json"
with zipfile.ZipFile(src, "r") as z:
    assert main_file in z.namelist(), "Not a compatible 0.9.10 archive"
    files = {name: z.read(name) for name in z.namelist() if not name.endswith("/")}
old = json.loads(files[main_file].decode("utf-8"))
assert old.get("type") == "minecraft:multi_action"
assert old.get("actions")
new_button = {
    "label": "☕ Редактор блюд — GUI 1.0",
    "width": 175,
    "action": {"type": "run_command", "command": "cafeui"}
}
old["actions"] = [a for a in old["actions"] if a.get("action", {}).get("command") != "cafeui"]
old["actions"].insert(0, new_button)
files[main_file] = json.dumps(old, ensure_ascii=False, indent=2).encode("utf-8")
with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path, data in files.items(): z.writestr(path,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    assert json.loads(z.read(main_file))["actions"][0] == new_button
print("Patched Lite archive created:", dest)
print("IMPORTANT: DO NOT install it without a compiled mobcafeui addon.")
