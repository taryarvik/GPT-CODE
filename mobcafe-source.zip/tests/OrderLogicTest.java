import com.mobcafeui.core.CatalogLogic;
import com.mobcafeui.core.OrderLogic;
import java.util.*;
public class OrderLogicTest {
  private static int assertions;
  private static void ok(boolean b, String reason) { assertions++; if(!b) throw new AssertionError(reason); }
  public static void main(String[] args) {
    List<Boolean> e = Arrays.asList(false,false,true,false,true,false);
    int a=0,b=0;
    Random rng = new Random(12345L);
    for(int i=0;i<10000;i++) {
      int s=OrderLogic.chooseSlot(e,rng); ok(s==2||s==4,"ineligible selected");
      if(s==2)a++;else b++;
    }
    ok(Math.abs(a-b)<600,"unbalanced random selection");
    ok(OrderLogic.chooseSlot(Arrays.asList(false,false),new Random())==-1,"empty catalogue fallback");
    for(int slot=0;slot<CatalogLogic.SLOTS;slot++) {
      int marker=OrderLogic.marker(slot);
      ok(OrderLogic.isCustom(marker),"custom marker");
      ok(OrderLogic.slotFromMarker(marker)==slot,"round-trip");
    }
    ok(!OrderLogic.isCustom(99),"vanilla marker");
    ok(!OrderLogic.isCustom(127),"out-of-range marker");
    ok(OrderLogic.payout(8,false)==8,"normal payment");
    ok(OrderLogic.payout(8,true)==9,"tip");
    ok(OrderLogic.payout(300,true)==65,"price max clamp");
    System.out.println("PASS " + assertions + " order checks");
  }
}
