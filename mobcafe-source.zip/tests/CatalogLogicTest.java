import com.mobcafeui.core.CatalogLogic;

public class CatalogLogicTest {
    private static int cases = 0;
    private static void eq(int expected, int result) {
        if (expected != result) throw new AssertionError("Expected " + expected + " got " + result);
        cases++;
    }
    public static void main(String[] args) {
        eq(1, CatalogLogic.price(-100));
        eq(1, CatalogLogic.price(0));
        eq(12, CatalogLogic.price(12));
        eq(64, CatalogLogic.price(9999));
        for (int slot = 0; slot < 27; slot++) for (int action = 0; action < 3; action++) {
            int id = CatalogLogic.buttonId(slot, action);
            eq(slot, CatalogLogic.slotForButton(id));
            eq(action, CatalogLogic.actionForButton(id));
        }
        System.out.println("PASS " + cases + " assertions");
    }
}
