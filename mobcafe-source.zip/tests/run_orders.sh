#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/order-tests
javac -encoding UTF-8 -d build/order-tests src/main/java/com/mobcafeui/core/CatalogLogic.java src/main/java/com/mobcafeui/core/OrderLogic.java tests/OrderLogicTest.java
java -cp build/order-tests OrderLogicTest
