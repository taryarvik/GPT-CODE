#!/usr/bin/env python3
"""Static integration checks, never a substitute for NeoForge compilation."""
from pathlib import Path
import sys, json, zipfile, re
root=Path(__file__).resolve().parents[1]
bridge=root/'bridge/MobCafe-Lite-0.9.10-UI-Bridge.jar'
base=root/'bridge/original-lite-0.9.10.jar'
with zipfile.ZipFile(bridge) as z, zipfile.ZipFile(base) as b:
    assert z.testzip() is None
    names=set(z.namelist()); old=set(b.namelist());assert names==old
    changed=[]
    for name in names:
        if z.read(name)!=b.read(name):changed.append(name)
    print('Changed Lite files:',len(changed))
    assert len(changed)==9,changed
    for name in names:
        if name.endswith('.json') or name.endswith('.mcmeta'):
            json.loads(z.read(name))
    def fn(path):return z.read('data/mobcafe_lite/function/'+path+'.mcfunction').decode('utf8')
    assert 'cafeui assign' in fn('seating/seated_waiting')
    assert 'cafeui serve' in fn('hand/try')
    assert 'cafeui barrel' in fn('counter/scan')
    for p in ['guest/angry','guest/finish_visit','guest/cleanup_only']:
        assert 'cafeui cancel' in fn(p)
    assert 'cafeui' in z.read('data/mobcafe_lite/dialog/main.json').decode('utf8')
    assert 'mobcafeui' not in z.read('META-INF/neoforge.mods.toml').decode('utf8'), 'no circular dependency'
    print('PASS: JSON, 7 hooks, 1 menu button and no missing/removed resources')
# Validate referenced new commands actually exist in server code
j=(root/'src/main/java/com/mobcafeui/order/LiteOrderBridge.java').read_text()
for command in ['assign','serve','barrel','cancel']:
    assert f'Commands.literal("{command}")' in j
# Critical invariant: remove order before paying (idempotency)
assert j.index('OrderStore.get(level).remove(guest.getStringUUID())') < j.index('new ItemEntity(level')
print('PASS: bridge hooks map to commands and payment is idempotent')
