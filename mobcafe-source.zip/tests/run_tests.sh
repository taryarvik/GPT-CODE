#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/core-test
javac -d build/core-test src/main/java/com/mobcafeui/core/CatalogLogic.java tests/CatalogLogicTest.java
java -cp build/core-test CatalogLogicTest
